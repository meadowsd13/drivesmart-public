package com.example.drivingtutorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class LearnFunction3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.learn_function3);
    }
}
